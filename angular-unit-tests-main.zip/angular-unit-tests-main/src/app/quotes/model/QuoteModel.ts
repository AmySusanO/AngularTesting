export class QuoteModel {
  constructor(public text: String, public timeCreated: String) {}
}
